<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\Paginator;
use App\Models\Site_model;
use App\Models\Proyek_model;
Paginator::useBootstrap();

class Proyek extends Controller
{
    // Main page
    public function index()
    {
        $site_config   = DB::table('konfigurasi')->first();
        $myproyek       = new Proyek_model();
        $proyek         = $myproyek->semua();
        $status_proyek  = DB::table('status_proyek')->orderBy('urutan','ASC')->get();

		$data = array(  'title'			=> 'Proyek '.$site_config->namaweb,
						'deskripsi' 	=> 'Proyek '.$site_config->namaweb,
                        'keywords'  	=> 'Proyek '.$site_config->namaweb,
                        'proyek'        => $proyek,
                        'status_proyek' => $status_proyek,
                        'proyek2'       => $proyek,
                        'content'		=> 'proyek/index'
                    );
        return view('layout/wrapper',$data);
    }

    // Main page
    public function detail($id_proyek)
    {
        $site_config   = DB::table('konfigurasi')->first();
        $myproyek       = new Proyek_model();
        $proyek         = $myproyek->detail($id_proyek);
        $proyek2        = $myproyek->semua();
        $status_proyek  = DB::table('status_proyek')->orderBy('urutan','ASC')->get();

        $data = array(  'title'         => $proyek->nama_proyek,
                        'deskripsi'     => $proyek->nama_proyek,
                        'keywords'      => $proyek->nama_proyek,
                        'proyek'        => $proyek,
                        'status_proyek' => $status_proyek,
                        'proyek2'       => $proyek2,
                        'content'       => 'proyek/detail'
                    );
        return view('layout/wrapper',$data);
    }
}
