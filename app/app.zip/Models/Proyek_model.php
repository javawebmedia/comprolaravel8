<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Proyek_model extends Model
{

	protected $table 		= "proyek";
	protected $primaryKey 	= 'id_proyek';

    // listing
    public function semua()
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->orderBy('proyek.id_proyek','DESC')
            ->get();
        return $query;
    }

    // listing
    public function home()
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->limit(4)
            ->orderBy('proyek.id_proyek','DESC')
            ->get();
        return $query;
    }

    // listing
    public function cari($keywords)
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->where('proyek.nama_proyek', 'LIKE', "%{$keywords}%") 
            ->orWhere('proyek.isi', 'LIKE', "%{$keywords}%") 
            ->orderBy('id_proyek','DESC')
            ->get();
        return $query;
    }

    // listing
    public function listing()
    {
    	$query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->where('status_proyek','Publish')
            ->orderBy('id_proyek','DESC')
            ->get();
        return $query;
    }

    // status
    public function status_proyek($id_status_proyek)
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->where(array(  'proyek.id_status_proyek'         => 'Publish',
                            'proyek.id_status_proyek'    => $id_status_proyek))
            ->orderBy('id_proyek','DESC')
            ->get();
        return $query;
    }

    // status
    public function all_status_proyek($id_status_proyek)
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->where(array(  'proyek.id_status_proyek'    => $id_status_proyek))
            ->orderBy('id_proyek','DESC')
            ->get();
        return $query;
    }

    // status
    public function status_proyeks($id_status_proyek)
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->where(array(  'proyek.id_status_proyek'         => $id_status_proyek))
            ->orderBy('id_proyek','DESC')
            ->get();
        return $query;
    }

    // status
    public function detail_status_proyek($id_status_proyek)
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->where(array(  'proyek.id_status_proyek'         => 'Publish',
                            'proyek.id_status_proyek'    => $id_status_proyek))
            ->orderBy('id_proyek','DESC')
            ->first();
        return $query;
    }

    // status
    public function detail_slug_status_proyek($slug_status_proyek)
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->where(array(  'proyek.id_status_proyek'                  => 'Publish',
                            'status_proyek.slug_status_proyek'  => $slug_status_proyek))
            ->orderBy('id_proyek','DESC')
            ->first();
        return $query;
    }


    // status
    public function slug_status_proyek($slug_status_proyek)
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->where(array(  'proyek.id_status_proyek'                  => 'Publish',
                            'status_proyek.slug_status_proyek'  => $slug_status_proyek))
            ->orderBy('id_proyek','DESC')
            ->get();
        return $query;
    }

    // detail
    public function read($slug_proyek)
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->where('proyek.slug_proyek',$slug_proyek)
            ->orderBy('id_proyek','DESC')
            ->first();
        return $query;
    }

     // detail
    public function detail($id_proyek)
    {
        $query = DB::table('proyek')
            ->join('status_proyek', 'status_proyek.id_status_proyek', '=', 'proyek.id_status_proyek','LEFT')
            ->select('proyek.*', 'status_proyek.slug_status_proyek', 'status_proyek.nama_status_proyek')
            ->where('proyek.id_proyek',$id_proyek)
            ->orderBy('id_proyek','DESC')
            ->first();
        return $query;
    }

    // Gambar
    public function gambar($id_proyek)
    {
        $query = DB::table('gambar_proyek')
            ->select('*')
            ->where('gambar_proyek.id_proyek',$id_proyek)
            ->orderBy('id_proyek','DESC')
            ->get();
        return $query;
    }
}
