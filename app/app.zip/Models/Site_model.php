<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Site_model extends Model
{

	protected $table 		= "site";
	protected $primaryKey 	= 'id_site';

    // listing
    public function semua()
    {
        $query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->orderBy('site.id_site','DESC')
            ->get();
        return $query;
    }

    // listing
    public function cari($keywords)
    {
        $query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->where('site.nama_site', 'LIKE', "%{$keywords}%") 
            ->orWhere('site.isi', 'LIKE', "%{$keywords}%") 
            ->orderBy('id_site','DESC')
            ->get();
        return $query;
    }

    // listing
    public function listing()
    {
    	$query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->where('status_site','Publish')
            ->orderBy('id_site','DESC')
            ->get();
        return $query;
    }

    // status
    public function status_site($id_status_site)
    {
        $query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->where(array(  'site.id_status_site'         => 'Publish',
                            'site.id_status_site'    => $id_status_site))
            ->orderBy('id_site','DESC')
            ->get();
        return $query;
    }

    // status
    public function all_status_site($id_status_site)
    {
        $query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->where(array(  'site.id_status_site'    => $id_status_site))
            ->orderBy('id_site','DESC')
            ->get();
        return $query;
    }

    // status
    public function status_sites($id_status_site)
    {
        $query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->where(array(  'site.id_status_site'         => $id_status_site))
            ->orderBy('id_site','DESC')
            ->get();
        return $query;
    }

    // status
    public function detail_status_site($id_status_site)
    {
        $query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->where(array(  'site.id_status_site'         => 'Publish',
                            'site.id_status_site'    => $id_status_site))
            ->orderBy('id_site','DESC')
            ->first();
        return $query;
    }

    // status
    public function detail_slug_status_site($slug_status_site)
    {
        $query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->where(array(  'site.id_status_site'                  => 'Publish',
                            'status_site.slug_status_site'  => $slug_status_site))
            ->orderBy('id_site','DESC')
            ->first();
        return $query;
    }


    // status
    public function slug_status_site($slug_status_site)
    {
        $query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->where(array(  'site.id_status_site'                  => 'Publish',
                            'status_site.slug_status_site'  => $slug_status_site))
            ->orderBy('id_site','DESC')
            ->get();
        return $query;
    }

    // detail
    public function read($slug_site)
    {
        $query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->where('site.slug_site',$slug_site)
            ->orderBy('id_site','DESC')
            ->first();
        return $query;
    }

     // detail
    public function detail($id_site)
    {
        $query = DB::table('site')
            ->join('status_site', 'status_site.id_status_site', '=', 'site.id_status_site','LEFT')
            ->select('site.*', 'status_site.slug_status_site', 'status_site.nama_status_site')
            ->where('site.id_site',$id_site)
            ->orderBy('id_site','DESC')
            ->first();
        return $query;
    }

    // Gambar
    public function gambar($id_site)
    {
        $query = DB::table('gambar_site')
            ->select('*')
            ->where('gambar_site.id_site',$id_site)
            ->orderBy('id_site','DESC')
            ->get();
        return $query;
    }
}
