<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\Paginator;
use App\Models\Akreditasi_model;
Paginator::useBootstrap();

class Akreditasi extends Controller
{
    // Akreditasipage
    public function index()
    {
    	$site 	= DB::table('konfigurasi')->first();
    	$model 	= new Akreditasi_model();
		$akreditasi = $model->listing();

        $data = array(  'title'     	=> 'Penyedia Layanan Akreditasi',
                        'deskripsi' 	=> 'Penyedia Layanan Akreditasi',
                        'keywords'  	=> 'Penyedia Layanan Akreditasi',
                        'site'			=> $site,
                        'akreditasi'	=> $akreditasi,
                        'akreditasis'    => $akreditasi,
                        'content'   	=> 'akreditasi/index'
                    );
        return view('layout/wrapper',$data);
    }
}
