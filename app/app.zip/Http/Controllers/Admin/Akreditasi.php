<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Helpers\Tanggal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Image;
use App\Models\Akreditasi_model;

class Akreditasi extends Controller
{
    // Main page
    public function index()
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	$myakreditasi 			= new Akreditasi_model();
		$akreditasi 			= $myakreditasi->semua();
		$kategori_akreditasi 	= DB::table('kategori_akreditasi')->orderBy('urutan','ASC')->get();

		$data = array(  'title'				=> 'Data Accreditation Provider',
						'akreditasi'			=> $akreditasi,
						'kategori_akreditasi'	=> $kategori_akreditasi,
                        'content'			=> 'admin/akreditasi/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Main page
    public function detail($id_akreditasi)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $myakreditasi        = new Akreditasi_model();
        $akreditasi          = $myakreditasi->detail($id_akreditasi);

        $data = array(  'title'             => $akreditasi->nama_akreditasi,
                        'akreditasi'             => $akreditasi,
                        'content'           => 'admin/akreditasi/detail'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Cari
    public function cari(Request $request)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $myakreditasi           = new Akreditasi_model();
        $keywords           = $request->keywords;
        $akreditasi             = $myakreditasi->cari($keywords);
        $kategori_akreditasi    = DB::table('kategori_akreditasi')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Data Accreditation Provider',
                        'akreditasi'            => $akreditasi,
                        'kategori_akreditasi'   => $kategori_akreditasi,
                        'content'           => 'admin/akreditasi/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Proses
    public function proses(Request $request)
    {
        $site   = DB::table('konfigurasi')->first();
        // PROSES HAPUS MULTIPLE
        if(isset($_POST['hapus'])) {
            $id_akreditasinya       = $request->id_akreditasi;
            for($i=0; $i < sizeof($id_akreditasinya);$i++) {
                DB::table('akreditasi')->where('id_akreditasi',$id_akreditasinya[$i])->delete();
            }
            return redirect('admin/akreditasi')->with(['sukses' => 'Data telah dihapus']);
        // PROSES SETTING DRAFT
        }elseif(isset($_POST['update'])) {
            $id_akreditasinya       = $request->id_akreditasi;
            for($i=0; $i < sizeof($id_akreditasinya);$i++) {
                DB::table('akreditasi')->where('id_akreditasi',$id_akreditasinya[$i])->update([
                        'id_user'               => Session()->get('id_user'),
                        'id_kategori_akreditasi'    => $request->id_kategori_akreditasi
                    ]);
            }
            return redirect('admin/akreditasi')->with(['sukses' => 'Data kategori telah diubah']);
        }
    }

    //Status
    public function status_akreditasi($status_akreditasi)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $myakreditasi           = new Akreditasi_model();
        $akreditasi             = $myakreditasi->status_akreditasi($status_akreditasi);
        $kategori_akreditasi    = DB::table('kategori_akreditasi')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Data Accreditation Provider',
                        'akreditasi'            => $akreditasi,
                        'kategori_akreditasi'   => $kategori_akreditasi,
                        'content'           => 'admin/akreditasi/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    //Kategori
    public function kategori($id_kategori_akreditasi)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $myakreditasi           = new Akreditasi_model();
        $akreditasi             = $myakreditasi->all_kategori_akreditasi($id_kategori_akreditasi);
        $kategori_akreditasi    = DB::table('kategori_akreditasi')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Data Accreditation Provider',
                        'akreditasi'            => $akreditasi,
                        'kategori_akreditasi'   => $kategori_akreditasi,
                        'content'           => 'admin/akreditasi/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Tambah
    public function tambah()
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $kategori_akreditasi    = DB::table('kategori_akreditasi')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Tambah Accreditation Provider',
                        'kategori_akreditasi'   => $kategori_akreditasi,
                        'content'           => 'admin/akreditasi/tambah'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // edit
    public function edit($id_akreditasi)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $myakreditasi           = new Akreditasi_model();
        $akreditasi             = $myakreditasi->detail($id_akreditasi);
        $kategori_akreditasi    = DB::table('kategori_akreditasi')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Edit Accreditation Provider',
                        'akreditasi'            => $akreditasi,
                        'kategori_akreditasi'   => $kategori_akreditasi,
                        'content'           => 'admin/akreditasi/edit'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // tambah
    public function tambah_proses(Request $request)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        request()->validate([
                            'nama_akreditasi'   => 'required|unique:akreditasi',
                            'gambar'            => 'file|image|mimes:jpeg,png,jpg|max:8024',
                            ]);
        // UPLOAD START
        $image                  = $request->file('gambar');
        if(!empty($image)) {
            $filenamewithextension  = $request->file('gambar')->getClientOriginalName();
            $filename               = pathinfo($filenamewithextension, PATHINFO_FILENAME);
            $input['nama_file']     = Str::slug($filename, '-').'-'.time().'.'.$image->getClientOriginalExtension();
            $destinationPath        = './assets/upload/image/thumbs/';
            $img = Image::make($image->getRealPath(),array(
                'width'     => 150,
                'height'    => 150,
                'grayscale' => false
            ));
            $img->save($destinationPath.'/'.$input['nama_file']);
            $destinationPath = './assets/upload/image/';
            $image->move($destinationPath, $input['nama_file']);
            // END UPLOAD
            $slug_akreditasi = Str::slug($request->nama_akreditasi.'-'.$request->scope, '-');
            DB::table('akreditasi')->insert([
                'id_user'                   => Session()->get('id_user'),
                'id_kategori_akreditasi'    => $request->id_kategori_akreditasi,
                'nama_akreditasi'           => $request->nama_akreditasi,
                'slug_akreditasi'           => $slug_akreditasi,
                'scope'                     => $request->scope,
                'pic'                       => $request->pic,
                'email'                     => $request->email,
                'telepon'                   => $request->telepon,
                'website'                   => $request->website,
                'isi'                       => $request->isi,
                'gambar'                    => $input['nama_file'],
                'status_akreditasi'         => $request->status_akreditasi,
                'keywords'                  => $request->keywords,
                'urutan'                    => $request->urutan
            ]);
        }else{
            $slug_akreditasi = Str::slug($request->nama_akreditasi.'-'.$request->scope, '-'); 
            DB::table('akreditasi')->insert([
                'id_user'                   => Session()->get('id_user'),
                'id_kategori_akreditasi'    => $request->id_kategori_akreditasi,
                'nama_akreditasi'           => $request->nama_akreditasi,
                'slug_akreditasi'           => $slug_akreditasi,
                'scope'                     => $request->scope,
                'pic'                       => $request->pic,
                'email'                     => $request->email,
                'telepon'                   => $request->telepon,
                'website'                   => $request->website,
                'isi'                       => $request->isi,
                // 'gambar'                    => $input['nama_file'],
                'status_akreditasi'         => $request->status_akreditasi,
                'keywords'                  => $request->keywords,
                'urutan'                    => $request->urutan
            ]);
        }
        return redirect('admin/akreditasi')->with(['sukses' => 'Data telah ditambah']);
    }

    // edit
    public function edit_proses(Request $request)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        request()->validate([
                            'nama_akreditasi'  => 'required',
                            'gambar'        => 'file|image|mimes:jpeg,png,jpg|max:8024',
                            ]);
        // UPLOAD START
        $image                  = $request->file('gambar');
        if(!empty($image)) {
            $filenamewithextension  = $request->file('gambar')->getClientOriginalName();
            $filename               = pathinfo($filenamewithextension, PATHINFO_FILENAME);
            $input['nama_file']     = Str::slug($filename, '-').'-'.time().'.'.$image->getClientOriginalExtension();
            $destinationPath        = './assets/upload/image/thumbs/';
            $img = Image::make($image->getRealPath(),array(
                'width'     => 150,
                'height'    => 150,
                'grayscale' => false
            ));
            $img->save($destinationPath.'/'.$input['nama_file']);
            $destinationPath = './assets/upload/image/';
            $image->move($destinationPath, $input['nama_file']);
            // END UPLOAD
            $slug_akreditasi = Str::slug($request->nama_akreditasi.'-'.$request->scope, '-');
            DB::table('akreditasi')->where('id_akreditasi',$request->id_akreditasi)->update([
                'id_user'                   => Session()->get('id_user'),
                'id_kategori_akreditasi'    => $request->id_kategori_akreditasi,
                'nama_akreditasi'           => $request->nama_akreditasi,
                'slug_akreditasi'           => $slug_akreditasi,
                'scope'                     => $request->scope,
                'pic'                       => $request->pic,
                'email'                     => $request->email,
                'telepon'                   => $request->telepon,
                'website'                   => $request->website,
                'isi'                       => $request->isi,
                'gambar'                    => $input['nama_file'],
                'status_akreditasi'         => $request->status_akreditasi,
                'keywords'                  => $request->keywords,
                'urutan'                    => $request->urutan
            ]);
        }else{
            $slug_akreditasi = Str::slug($request->nama_akreditasi.'-'.$request->scope, '-');
            DB::table('akreditasi')->where('id_akreditasi',$request->id_akreditasi)->update([
                'id_user'                   => Session()->get('id_user'),
                'id_kategori_akreditasi'    => $request->id_kategori_akreditasi,
                'nama_akreditasi'           => $request->nama_akreditasi,
                'slug_akreditasi'           => $slug_akreditasi,
                'scope'                     => $request->scope,
                'pic'                       => $request->pic,
                'email'                     => $request->email,
                'telepon'                   => $request->telepon,
                'website'                   => $request->website,
                'isi'                       => $request->isi,
                // 'gambar'                    => $input['nama_file'],
                'status_akreditasi'         => $request->status_akreditasi,
                'keywords'                  => $request->keywords,
                'urutan'                    => $request->urutan
            ]);
        }
        return redirect('admin/akreditasi')->with(['sukses' => 'Data telah ditambah']);
    }

    // Delete
    public function delete($id_akreditasi)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        DB::table('akreditasi')->where('id_akreditasi',$id_akreditasi)->delete();
        return redirect('admin/akreditasi')->with(['sukses' => 'Data telah dihapus']);
    }
}
