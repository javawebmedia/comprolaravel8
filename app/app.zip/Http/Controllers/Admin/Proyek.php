<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Image;
use App\Models\Proyek_model;

class Proyek extends Controller
{
    // Main page
    public function index()
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	$myproyek 			= new Proyek_model();
		$proyek 			= $myproyek->semua();
		$status_proyek 	= DB::table('status_proyek')->orderBy('urutan','ASC')->get();

		$data = array(  'title'				=> 'Data Proyek ',
						'proyek'			=> $proyek,
						'status_proyek'	=> $status_proyek,
                        'content'			=> 'admin/proyek/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Main page
    public function detail($id_proyek)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $myproyek        = new Proyek_model();
        $proyek          = $myproyek->detail($id_proyek);

        $data = array(  'title'             => $proyek->nama_proyek,
                        'proyek'             => $proyek,
                        'content'           => 'admin/proyek/detail'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Cari
    public function cari(Request $request)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $myproyek           = new Proyek_model();
        $keywords           = $request->keywords;
        $proyek             = $myproyek->cari($keywords);
        $status_proyek    = DB::table('status_proyek')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Data Proyek ',
                        'proyek'            => $proyek,
                        'status_proyek'   => $status_proyek,
                        'content'           => 'admin/proyek/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Proses
    public function proses(Request $request)
    {
        $proyek   = DB::table('konfigurasi')->first();
        // PROSES HAPUS MULTIPLE
        if(isset($_POST['hapus'])) {
            $id_proyeknya       = $request->id_proyek;
            for($i=0; $i < sizeof($id_proyeknya);$i++) {
                DB::table('proyek')->where('id_proyek',$id_proyeknya[$i])->delete();
            }
            return redirect('admin/proyek')->with(['sukses' => 'Data telah dihapus']);
        // PROSES SETTING DRAFT
        }elseif(isset($_POST['update'])) {
            $id_proyeknya       = $request->id_proyek;
            for($i=0; $i < sizeof($id_proyeknya);$i++) {
                DB::table('proyek')->where('id_proyek',$id_proyeknya[$i])->update([
                        'id_user'               => Session()->get('id_user'),
                        'id_status_proyek'    => $request->id_status_proyek
                    ]);
            }
            return redirect('admin/proyek')->with(['sukses' => 'Data status telah diubah']);
        }
    }

    //Status
    public function status_proyek($status_proyek)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $myproyek           = new Proyek_model();
        $proyek             = $myproyek->status_proyek($status_proyek);
        $status_proyek    = DB::table('status_proyek')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Data Proyek ',
                        'proyek'            => $proyek,
                        'status_proyek'   => $status_proyek,
                        'content'           => 'admin/proyek/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    //Kategori
    public function status($id_status_proyek)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $myproyek           = new Proyek_model();
        $proyek             = $myproyek->all_status_proyek($id_status_proyek);
        $status_proyek_detail      = DB::table('status_proyek')->where('id_status_proyek',$id_status_proyek)->orderBy('urutan','ASC')->first();
        $status_proyek    = DB::table('status_proyek')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Status Proyek: '.$status_proyek_detail->nama_status_proyek,
                        'proyek'              => $proyek,
                        'status_proyek'       => $status_proyek,
                        'content'           => 'admin/proyek/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Tambah
    public function tambah()
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $status_proyek    = DB::table('status_proyek')->orderBy('urutan','ASC')->get();

        $data = array(  'title'         => 'Tambah Proyek ',
                        'status_proyek'   => $status_proyek,
                        'content'       => 'admin/proyek/tambah'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // edit
    public function edit($id_proyek)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $myproyek           = new Proyek_model();
        $proyek             = $myproyek->detail($id_proyek);
        $status_proyek    = DB::table('status_proyek')->orderBy('urutan','ASC')->get();

        $data = array(  'title'         => 'Edit Proyek: '.$proyek->nama_proyek,
                        'proyek'          => $proyek,
                        'status_proyek'   => $status_proyek,
                        'content'       => 'admin/proyek/edit'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // tambah
    public function tambah_proses(Request $request)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        request()->validate([
                            'nama_proyek'  => 'required|unique:proyek',
                            'gambar'     => 'file|image|mimes:jpeg,png,jpg|max:8024',
                            ]);
        // UPLOAD START
        $image                  = $request->file('gambar');
        if(!empty($image)) {
            $filenamewithextension  = $request->file('gambar')->getClientOriginalName();
            $filename               = pathinfo($filenamewithextension, PATHINFO_FILENAME);
            $input['nama_file']     = Str::slug($filename, '-').'-'.time().'.'.$image->getClientOriginalExtension();
            $destinationPath        = './assets/upload/image/thumbs';
            $img = Image::make($image->getRealPath(),array(
                'width'     => 150,
                'height'    => 150,
                'grayscale' => false
            ));
            $img->save($destinationPath.'/'.$input['nama_file']);
            $destinationPath = './assets/upload/image';
            $image->move($destinationPath, $input['nama_file']);
            // END UPLOAD
            $slug_proyek = Str::slug($request->nama_proyek.'-'.$request->jabatan, '-');
            DB::table('proyek')->insert([
                'id_user'               => Session()->get('id_user'),
                'id_status_proyek'        => $request->id_status_proyek,
                'kode_proyek'             => $request->kode_proyek,
                'nama_proyek'             => $request->nama_proyek,
                'mitra'                 => $request->mitra,
                'pic'                   => $request->pic,
                'telepon'               => $request->telepon,
                'email'                 => $request->email,
                'alamat'                => $request->alamat,
                'keterangan'            => $request->keterangan,
                'tanggal_penerbitan'    => tanggal('tanggal_input',$request->tanggal_penerbitan),
                'tanggal_audit'         => tanggal('tanggal_input',$request->tanggal_audit),
                'tanggal_audit_end'     => tanggal('tanggal_input',$request->tanggal_audit_end),
                'gambar'                => $input['nama_file'],
                'latitude'              => $request->latitude,
                'longitude'             => $request->longitude,
                'peta_google_map'       => $request->peta_google_map,
                'urutan'                => $request->urutan,
                'posted_on'             => date('Y-m-d H:i:s')
            ]);
        }else{
            $slug_proyek = Str::slug($request->nama_proyek.'-'.$request->jabatan, '-'); 
            DB::table('proyek')->insert([
                'id_user'               => Session()->get('id_user'),
                'id_status_proyek'        => $request->id_status_proyek,
                'kode_proyek'             => $request->kode_proyek,
                'nama_proyek'             => $request->nama_proyek,
                'mitra'                 => $request->mitra,
                'pic'                   => $request->pic,
                'telepon'               => $request->telepon,
                'email'                 => $request->email,
                'alamat'                => $request->alamat,
                'keterangan'            => $request->keterangan,
                'tanggal_penerbitan'    => tanggal('tanggal_input',$request->tanggal_penerbitan),
                'tanggal_audit'         => tanggal('tanggal_input',$request->tanggal_audit),
                'tanggal_audit_end'     => tanggal('tanggal_input',$request->tanggal_audit_end),
                // 'gambar'                => $input['nama_file'],
                'latitude'              => $request->latitude,
                'longitude'             => $request->longitude,
                'peta_google_map'       => $request->peta_google_map,
                'urutan'                => $request->urutan,
                'posted_on'             => date('Y-m-d H:i:s')
            ]);
        }
        return redirect('admin/proyek')->with(['sukses' => 'Data telah ditambah']);
    }

    // edit
    public function edit_proses(Request $request)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        request()->validate([
                            'nama_proyek'  => 'required',
                            'gambar'        => 'file|image|mimes:jpeg,png,jpg|max:8024',
                            ]);
        // UPLOAD START
        $image                  = $request->file('gambar');
        if(!empty($image)) {
            $filenamewithextension  = $request->file('gambar')->getClientOriginalName();
            $filename               = pathinfo($filenamewithextension, PATHINFO_FILENAME);
            $input['nama_file']     = Str::slug($filename, '-').'-'.time().'.'.$image->getClientOriginalExtension();
            $destinationPath        = './assets/upload/image/thumbs';
            $img = Image::make($image->getRealPath(),array(
                'width'     => 150,
                'height'    => 150,
                'grayscale' => false
            ));
            $img->save($destinationPath.'/'.$input['nama_file']);
            $destinationPath = './assets/upload/image';
            $image->move($destinationPath, $input['nama_file']);
            // END UPLOAD
            $slug_proyek = Str::slug($request->nama_proyek.'-'.$request->jabatan, '-');
            DB::table('proyek')->where('id_proyek',$request->id_proyek)->update([
                'id_user'               => Session()->get('id_user'),
                'id_status_proyek'        => $request->id_status_proyek,
                'kode_proyek'             => $request->kode_proyek,
                'nama_proyek'             => $request->nama_proyek,
                'mitra'                 => $request->mitra,
                'pic'                   => $request->pic,
                'telepon'               => $request->telepon,
                'email'                 => $request->email,
                'alamat'                => $request->alamat,
                'keterangan'            => $request->keterangan,
                'tanggal_penerbitan'    => tanggal('tanggal_input',$request->tanggal_penerbitan),
                'tanggal_audit'         => tanggal('tanggal_input',$request->tanggal_audit),
                'tanggal_audit_end'     => tanggal('tanggal_input',$request->tanggal_audit_end),
                'gambar'                => $input['nama_file'],
                'latitude'              => $request->latitude,
                'longitude'             => $request->longitude,
                'peta_google_map'       => $request->peta_google_map,
                'urutan'                => $request->urutan
            ]);
        }else{
            $slug_proyek = Str::slug($request->nama_proyek.'-'.$request->jabatan, '-');
            DB::table('proyek')->where('id_proyek',$request->id_proyek)->update([
                'id_user'               => Session()->get('id_user'),
                'id_status_proyek'        => $request->id_status_proyek,
                'kode_proyek'             => $request->kode_proyek,
                'nama_proyek'             => $request->nama_proyek,
                'mitra'                 => $request->mitra,
                'pic'                   => $request->pic,
                'telepon'               => $request->telepon,
                'email'                 => $request->email,
                'alamat'                => $request->alamat,
                'keterangan'            => $request->keterangan,
                'tanggal_penerbitan'    => tanggal('tanggal_input',$request->tanggal_penerbitan),
                'tanggal_audit'         => tanggal('tanggal_input',$request->tanggal_audit),
                'tanggal_audit_end'     => tanggal('tanggal_input',$request->tanggal_audit_end),
                // 'gambar'                => $input['nama_file'],
                'latitude'              => $request->latitude,
                'longitude'             => $request->longitude,
                'peta_google_map'       => $request->peta_google_map,
                'urutan'                => $request->urutan
            ]);
        }
        return redirect('admin/proyek')->with(['sukses' => 'Data telah diupdate']);
    }

    // Delete
    public function delete($id_proyek)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        DB::table('proyek')->where('id_proyek',$id_proyek)->delete();
        return redirect('admin/proyek')->with(['sukses' => 'Data telah dihapus']);
    }
}
