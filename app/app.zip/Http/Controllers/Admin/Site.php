<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Image;
use App\Models\Site_model;

class Site extends Controller
{
    // Main page
    public function index()
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	$mysite 			= new Site_model();
		$site 			= $mysite->semua();
		$status_site 	= DB::table('status_site')->orderBy('urutan','ASC')->get();

		$data = array(  'title'				=> 'Data Site ',
						'site'			=> $site,
						'status_site'	=> $status_site,
                        'content'			=> 'admin/site/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Main page
    public function detail($id_site)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $mysite        = new Site_model();
        $site          = $mysite->detail($id_site);

        $data = array(  'title'             => $site->nama_site,
                        'site'             => $site,
                        'content'           => 'admin/site/detail'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Cari
    public function cari(Request $request)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $mysite           = new Site_model();
        $keywords           = $request->keywords;
        $site             = $mysite->cari($keywords);
        $status_site    = DB::table('status_site')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Data Site ',
                        'site'            => $site,
                        'status_site'   => $status_site,
                        'content'           => 'admin/site/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Proses
    public function proses(Request $request)
    {
        $site   = DB::table('konfigurasi')->first();
        // PROSES HAPUS MULTIPLE
        if(isset($_POST['hapus'])) {
            $id_sitenya       = $request->id_site;
            for($i=0; $i < sizeof($id_sitenya);$i++) {
                DB::table('site')->where('id_site',$id_sitenya[$i])->delete();
            }
            return redirect('admin/site')->with(['sukses' => 'Data telah dihapus']);
        // PROSES SETTING DRAFT
        }elseif(isset($_POST['update'])) {
            $id_sitenya       = $request->id_site;
            for($i=0; $i < sizeof($id_sitenya);$i++) {
                DB::table('site')->where('id_site',$id_sitenya[$i])->update([
                        'id_user'               => Session()->get('id_user'),
                        'id_status_site'    => $request->id_status_site
                    ]);
            }
            return redirect('admin/site')->with(['sukses' => 'Data status telah diubah']);
        }
    }

    //Status
    public function status_site($status_site)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $mysite           = new Site_model();
        $site             = $mysite->status_site($status_site);
        $status_site    = DB::table('status_site')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Data Site ',
                        'site'            => $site,
                        'status_site'   => $status_site,
                        'content'           => 'admin/site/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    //Kategori
    public function status($id_status_site)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $mysite           = new Site_model();
        $site             = $mysite->all_status_site($id_status_site);
        $status_site_detail      = DB::table('status_site')->where('id_status_site',$id_status_site)->orderBy('urutan','ASC')->first();
        $status_site    = DB::table('status_site')->orderBy('urutan','ASC')->get();

        $data = array(  'title'             => 'Status Site: '.$status_site_detail->nama_status_site,
                        'site'              => $site,
                        'status_site'       => $status_site,
                        'content'           => 'admin/site/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // Tambah
    public function tambah()
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $status_site    = DB::table('status_site')->orderBy('urutan','ASC')->get();

        $data = array(  'title'         => 'Tambah Site ',
                        'status_site'   => $status_site,
                        'content'       => 'admin/site/tambah'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // edit
    public function edit($id_site)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        $mysite           = new Site_model();
        $site             = $mysite->detail($id_site);
        $status_site    = DB::table('status_site')->orderBy('urutan','ASC')->get();

        $data = array(  'title'         => 'Edit Site: '.$site->nama_site,
                        'site'          => $site,
                        'status_site'   => $status_site,
                        'content'       => 'admin/site/edit'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // tambah
    public function tambah_proses(Request $request)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        request()->validate([
                            'nama_site'  => 'required|unique:site',
                            'gambar'     => 'required|file|image|mimes:jpeg,png,jpg|max:8024',
                            ]);
        // UPLOAD START
        $image                  = $request->file('gambar');
        if(!empty($image)) {
            $filenamewithextension  = $request->file('gambar')->getClientOriginalName();
            $filename               = pathinfo($filenamewithextension, PATHINFO_FILENAME);
            $input['nama_file']     = Str::slug($filename, '-').'-'.time().'.'.$image->getClientOriginalExtension();
            $destinationPath        = './assets/upload/image/thumbs';
            $img = Image::make($image->getRealPath(),array(
                'width'     => 150,
                'height'    => 150,
                'grayscale' => false
            ));
            $img->save($destinationPath.'/'.$input['nama_file']);
            $destinationPath = './assets/upload/image';
            $image->move($destinationPath, $input['nama_file']);
            // END UPLOAD
            $slug_site = Str::slug($request->nama_site.'-'.$request->jabatan, '-');
            DB::table('site')->insert([
                'id_user'               => Session()->get('id_user'),
                'id_status_site'        => $request->id_status_site,
                'kode_site'             => $request->kode_site,
                'nama_site'             => $request->nama_site,
                'pic'                   => $request->pic,
                'telepon'               => $request->telepon,
                'email'                 => $request->email,
                'alamat'                => $request->alamat,
                'keterangan'            => $request->keterangan,
                'tanggal_penerbitan'    => tanggal('tanggal_input',$request->tanggal_penerbitan),
                'tanggal_audit'         => tanggal('tanggal_input',$request->tanggal_audit),
                'tanggal_audit_end'     => tanggal('tanggal_input',$request->tanggal_audit_end),
                'gambar'                => $input['nama_file'],
                'latitude'              => $request->latitude,
                'longitude'             => $request->longitude,
                'peta_google_map'       => $request->peta_google_map,
                'urutan'                => $request->urutan,
                'posted_on'             => date('Y-m-d H:i:s')
            ]);
        }else{
            $slug_site = Str::slug($request->nama_site.'-'.$request->jabatan, '-'); 
            DB::table('site')->insert([
                'id_user'               => Session()->get('id_user'),
                'id_status_site'        => $request->id_status_site,
                'kode_site'             => $request->kode_site,
                'nama_site'             => $request->nama_site,
                'pic'                   => $request->pic,
                'telepon'               => $request->telepon,
                'email'                 => $request->email,
                'alamat'                => $request->alamat,
                'keterangan'            => $request->keterangan,
                'tanggal_penerbitan'    => tanggal('tanggal_input',$request->tanggal_penerbitan),
                'tanggal_audit'         => tanggal('tanggal_input',$request->tanggal_audit),
                'tanggal_audit_end'     => tanggal('tanggal_input',$request->tanggal_audit_end),
                // 'gambar'                => $input['nama_file'],
                'latitude'              => $request->latitude,
                'longitude'             => $request->longitude,
                'peta_google_map'       => $request->peta_google_map,
                'urutan'                => $request->urutan,
                'posted_on'             => date('Y-m-d H:i:s')
            ]);
        }
        return redirect('admin/site')->with(['sukses' => 'Data telah ditambah']);
    }

    // edit
    public function edit_proses(Request $request)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        request()->validate([
                            'nama_site'  => 'required',
                            'gambar'        => 'file|image|mimes:jpeg,png,jpg|max:8024',
                            ]);
        // UPLOAD START
        $image                  = $request->file('gambar');
        if(!empty($image)) {
            $filenamewithextension  = $request->file('gambar')->getClientOriginalName();
            $filename               = pathinfo($filenamewithextension, PATHINFO_FILENAME);
            $input['nama_file']     = Str::slug($filename, '-').'-'.time().'.'.$image->getClientOriginalExtension();
            $destinationPath        = './assets/upload/image/thumbs';
            $img = Image::make($image->getRealPath(),array(
                'width'     => 150,
                'height'    => 150,
                'grayscale' => false
            ));
            $img->save($destinationPath.'/'.$input['nama_file']);
            $destinationPath = './assets/upload/image';
            $image->move($destinationPath, $input['nama_file']);
            // END UPLOAD
            $slug_site = Str::slug($request->nama_site.'-'.$request->jabatan, '-');
            DB::table('site')->where('id_site',$request->id_site)->update([
                'id_user'               => Session()->get('id_user'),
                'id_status_site'        => $request->id_status_site,
                'kode_site'             => $request->kode_site,
                'nama_site'             => $request->nama_site,
                'pic'                   => $request->pic,
                'telepon'               => $request->telepon,
                'email'                 => $request->email,
                'alamat'                => $request->alamat,
                'keterangan'            => $request->keterangan,
                'tanggal_penerbitan'    => tanggal('tanggal_input',$request->tanggal_penerbitan),
                'tanggal_audit'         => tanggal('tanggal_input',$request->tanggal_audit),
                'tanggal_audit_end'     => tanggal('tanggal_input',$request->tanggal_audit_end),
                'gambar'                => $input['nama_file'],
                'latitude'              => $request->latitude,
                'longitude'             => $request->longitude,
                'peta_google_map'       => $request->peta_google_map,
                'urutan'                => $request->urutan
            ]);
        }else{
            $slug_site = Str::slug($request->nama_site.'-'.$request->jabatan, '-');
            DB::table('site')->where('id_site',$request->id_site)->update([
                'id_user'               => Session()->get('id_user'),
                'id_status_site'        => $request->id_status_site,
                'kode_site'             => $request->kode_site,
                'nama_site'             => $request->nama_site,
                'pic'                   => $request->pic,
                'telepon'               => $request->telepon,
                'email'                 => $request->email,
                'alamat'                => $request->alamat,
                'keterangan'            => $request->keterangan,
                'tanggal_penerbitan'    => tanggal('tanggal_input',$request->tanggal_penerbitan),
                'tanggal_audit'         => tanggal('tanggal_input',$request->tanggal_audit),
                'tanggal_audit_end'     => tanggal('tanggal_input',$request->tanggal_audit_end),
                // 'gambar'                => $input['nama_file'],
                'latitude'              => $request->latitude,
                'longitude'             => $request->longitude,
                'peta_google_map'       => $request->peta_google_map,
                'urutan'                => $request->urutan
            ]);
        }
        return redirect('admin/site')->with(['sukses' => 'Data telah diupdate']);
    }

    // Delete
    public function delete($id_site)
    {
        if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
        DB::table('site')->where('id_site',$id_site)->delete();
        return redirect('admin/site')->with(['sukses' => 'Data telah dihapus']);
    }
}
