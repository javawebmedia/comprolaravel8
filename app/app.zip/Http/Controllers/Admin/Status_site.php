<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Image;

class Status_site extends Controller
{
    // Index
    public function index()
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
		$status_site 	= DB::table('status_site')->orderBy('urutan','ASC')->get();

		$data = array(  'title'             => 'Status Site',
						'status_site'	    => $status_site,
                        'content'           => 'admin/status_site/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // tambah
    public function tambah(Request $request)
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	request()->validate([
					        'nama_status_site' => 'required|unique:status_site',
					        'urutan' 		       => 'required',
                            'gambar'               => 'required|file|image|mimes:jpeg,png,jpg|max:8024',
					        ]);
        // UPLOAD START
        $image                  = $request->file('gambar');
        $filenamewithextension  = $request->file('gambar')->getClientOriginalName();
        $filename               = pathinfo($filenamewithextension, PATHINFO_FILENAME);
        $input['nama_file']     = Str::slug($filename, '-').'-'.time().'.'.$image->getClientOriginalExtension();
        $destinationPath        = './assets/upload/image/thumbs';
        $img = Image::make($image->getRealPath(),array(
            'width'     => 150,
            'height'    => 150,
            'grayscale' => false
        ));
        $img->save($destinationPath.'/'.$input['nama_file']);
        $destinationPath = './assets/upload/image';
        $image->move($destinationPath, $input['nama_file']);
        // END UPLOAD
    	$slug_status_site = Str::slug($request->nama_status_site, '-');
        DB::table('status_site')->insert([
            'nama_status_site'  => $request->nama_status_site,
            'slug_status_site'	=> $slug_status_site,
            'urutan'   		        => $request->urutan,
            'keterangan'            => $request->keterangan,
            'gambar'                => $input['nama_file'],
            'status_icon'           => $request->status_icon,
            'status_class'          => $request->status_class
        ]);
        return redirect('admin/status_site')->with(['sukses' => 'Data telah ditambah']);
    }

    // edit
    public function edit(Request $request)
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	request()->validate([
					        'nama_status_site' => 'required',
					        'urutan'               => 'required',
                            'gambar'               => 'file|image|mimes:jpeg,png,jpg|max:8024',
					        ]);
        // UPLOAD START
        $image                  = $request->file('gambar');
        if(!empty($image)) {
            // UPLOAD START
            $filenamewithextension  = $request->file('gambar')->getClientOriginalName();
            $filename               = pathinfo($filenamewithextension, PATHINFO_FILENAME);
            $input['nama_file']     = Str::slug($filename, '-').'-'.time().'.'.$image->getClientOriginalExtension();
            $destinationPath        = './assets/upload/image/thumbs';
            $img = Image::make($image->getRealPath(),array(
                'width'     => 150,
                'height'    => 150,
                'grayscale' => false
            ));
            $img->save($destinationPath.'/'.$input['nama_file']);
            $destinationPath = './assets/upload/image';
            $image->move($destinationPath, $input['nama_file']);
            // END UPLOAD
            $slug_status_site = Str::slug($request->nama_status_site, '-');
            DB::table('status_site')->where('id_status_site',$request->id_status_site)->update([
                'nama_status_site'  => $request->nama_status_site,
                'slug_status_site'  => $slug_status_site,
                'urutan'                => $request->urutan,
                'keterangan'            => $request->keterangan,
                'gambar'                => $input['nama_file'],
                'status_icon'           => $request->status_icon,
                'status_class'          => $request->status_class
            ]);
        }else{
            $slug_status_site = Str::slug($request->nama_status_site, '-');
            DB::table('status_site')->where('id_status_site',$request->id_status_site)->update([
                'nama_status_site'  => $request->nama_status_site,
                'slug_status_site'  => $slug_status_site,
                'urutan'                => $request->urutan,
                'keterangan'            => $request->keterangan,
                'status_icon'           => $request->status_icon,
                'status_class'          => $request->status_class
            ]);
        }
        return redirect('admin/status_site')->with(['sukses' => 'Data telah diupdate']);
    }

    // Delete
    public function delete($id_status_site)
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	DB::table('status_site')->where('id_status_site',$id_status_site)->delete();
    	return redirect('admin/status_site')->with(['sukses' => 'Data telah dihapus']);
    }
}
