<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Image;

class Status_proyek extends Controller
{
    // Index
    public function index()
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
		$status_proyek 	= DB::table('status_proyek')->orderBy('urutan','ASC')->get();

		$data = array(  'title'             => 'Status Proyek',
						'status_proyek'	    => $status_proyek,
                        'content'           => 'admin/status_proyek/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // tambah
    public function tambah(Request $request)
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	request()->validate([
					        'nama_status_proyek' => 'required|unique:status_proyek',
					        'urutan' 		       => 'required',
                            'gambar'               => 'required|file|image|mimes:jpeg,png,jpg|max:8024',
					        ]);
        // UPLOAD START
        $image                  = $request->file('gambar');
        $filenamewithextension  = $request->file('gambar')->getClientOriginalName();
        $filename               = pathinfo($filenamewithextension, PATHINFO_FILENAME);
        $input['nama_file']     = Str::slug($filename, '-').'-'.time().'.'.$image->getClientOriginalExtension();
        $destinationPath        = './assets/upload/image/thumbs';
        $img = Image::make($image->getRealPath(),array(
            'width'     => 150,
            'height'    => 150,
            'grayscale' => false
        ));
        $img->save($destinationPath.'/'.$input['nama_file']);
        $destinationPath = './assets/upload/image';
        $image->move($destinationPath, $input['nama_file']);
        // END UPLOAD
    	$slug_status_proyek = Str::slug($request->nama_status_proyek, '-');
        DB::table('status_proyek')->insert([
            'nama_status_proyek'  => $request->nama_status_proyek,
            'slug_status_proyek'	=> $slug_status_proyek,
            'urutan'   		        => $request->urutan,
            'keterangan'            => $request->keterangan,
            'gambar'                => $input['nama_file']
        ]);
        return redirect('admin/status_proyek')->with(['sukses' => 'Data telah ditambah']);
    }

    // edit
    public function edit(Request $request)
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	request()->validate([
					        'nama_status_proyek' => 'required',
					        'urutan'               => 'required',
                            'gambar'               => 'file|image|mimes:jpeg,png,jpg|max:8024',
					        ]);
        // UPLOAD START
        $image                  = $request->file('gambar');
        if(!empty($image)) {
            // UPLOAD START
            $filenamewithextension  = $request->file('gambar')->getClientOriginalName();
            $filename               = pathinfo($filenamewithextension, PATHINFO_FILENAME);
            $input['nama_file']     = Str::slug($filename, '-').'-'.time().'.'.$image->getClientOriginalExtension();
            $destinationPath        = './assets/upload/image/thumbs';
            $img = Image::make($image->getRealPath(),array(
                'width'     => 150,
                'height'    => 150,
                'grayscale' => false
            ));
            $img->save($destinationPath.'/'.$input['nama_file']);
            $destinationPath = './assets/upload/image';
            $image->move($destinationPath, $input['nama_file']);
            // END UPLOAD
            $slug_status_proyek = Str::slug($request->nama_status_proyek, '-');
            DB::table('status_proyek')->where('id_status_proyek',$request->id_status_proyek)->update([
                'nama_status_proyek'  => $request->nama_status_proyek,
                'slug_status_proyek'  => $slug_status_proyek,
                'urutan'                => $request->urutan,
                'keterangan'            => $request->keterangan,
                'gambar'                => $input['nama_file']
            ]);
        }else{
            $slug_status_proyek = Str::slug($request->nama_status_proyek, '-');
            DB::table('status_proyek')->where('id_status_proyek',$request->id_status_proyek)->update([
                'nama_status_proyek'  => $request->nama_status_proyek,
                'slug_status_proyek'  => $slug_status_proyek,
                'urutan'                => $request->urutan,
                'keterangan'            => $request->keterangan
            ]);
        }
        return redirect('admin/status_proyek')->with(['sukses' => 'Data telah diupdate']);
    }

    // Delete
    public function delete($id_status_proyek)
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	DB::table('status_proyek')->where('id_status_proyek',$id_status_proyek)->delete();
    	return redirect('admin/status_proyek')->with(['sukses' => 'Data telah dihapus']);
    }
}
