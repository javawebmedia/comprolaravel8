<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Akreditasi_model extends Model
{

	protected $table 		= "akreditasi";
	protected $primaryKey 	= 'id_akreditasi';

    // listing
    public function semua()
    {
        $query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->orderBy('akreditasi.id_akreditasi','DESC')
            ->get();
        return $query;
    }

    // listing
    public function cari($keywords)
    {
        $query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->where('akreditasi.nama_akreditasi', 'LIKE', "%{$keywords}%") 
            ->orWhere('akreditasi.isi', 'LIKE', "%{$keywords}%") 
            ->orderBy('id_akreditasi','DESC')
            ->get();
        return $query;
    }

    // listing
    public function listing()
    {
    	$query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->where('status_akreditasi','Ya')
            ->orderBy('id_akreditasi','DESC')
            ->get();
        return $query;
    }

    // kategori
    public function kategori_akreditasi($id_kategori_akreditasi)
    {
        $query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->where(array(  'akreditasi.status_akreditasi'         => 'Ya',
                            'akreditasi.id_kategori_akreditasi'    => $id_kategori_akreditasi))
            ->orderBy('id_akreditasi','DESC')
            ->get();
        return $query;
    }

    // kategori
    public function all_kategori_akreditasi($id_kategori_akreditasi)
    {
        $query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->where(array(  'akreditasi.id_kategori_akreditasi'    => $id_kategori_akreditasi))
            ->orderBy('id_akreditasi','DESC')
            ->get();
        return $query;
    }

    // kategori
    public function status_akreditasi($status_akreditasi)
    {
        $query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->where(array(  'akreditasi.status_akreditasi'         => $status_akreditasi))
            ->orderBy('id_akreditasi','DESC')
            ->get();
        return $query;
    }

    // kategori
    public function detail_kategori_akreditasi($id_kategori_akreditasi)
    {
        $query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->where(array(  'akreditasi.status_akreditasi'         => 'Ya',
                            'akreditasi.id_kategori_akreditasi'    => $id_kategori_akreditasi))
            ->orderBy('id_akreditasi','DESC')
            ->first();
        return $query;
    }

    // kategori
    public function detail_slug_kategori_akreditasi($slug_kategori_akreditasi)
    {
        $query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->where(array(  'akreditasi.status_akreditasi'                  => 'Ya',
                            'kategori_akreditasi.slug_kategori_akreditasi'  => $slug_kategori_akreditasi))
            ->orderBy('id_akreditasi','DESC')
            ->first();
        return $query;
    }


    // kategori
    public function slug_kategori_akreditasi($slug_kategori_akreditasi)
    {
        $query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->where(array(  'akreditasi.status_akreditasi'                  => 'Ya',
                            'kategori_akreditasi.slug_kategori_akreditasi'  => $slug_kategori_akreditasi))
            ->orderBy('id_akreditasi','DESC')
            ->get();
        return $query;
    }

    // detail
    public function read($slug_akreditasi)
    {
        $query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->where('akreditasi.slug_akreditasi',$slug_akreditasi)
            ->orderBy('id_akreditasi','DESC')
            ->first();
        return $query;
    }

     // detail
    public function detail($id_akreditasi)
    {
        $query = DB::table('akreditasi')
            ->join('kategori_akreditasi', 'kategori_akreditasi.id_kategori_akreditasi', '=', 'akreditasi.id_kategori_akreditasi','LEFT')
            ->select('akreditasi.*', 'kategori_akreditasi.slug_kategori_akreditasi', 'kategori_akreditasi.nama_kategori_akreditasi')
            ->where('akreditasi.id_akreditasi',$id_akreditasi)
            ->orderBy('id_akreditasi','DESC')
            ->first();
        return $query;
    }

    // Gambar
    public function gambar($id_akreditasi)
    {
        $query = DB::table('gambar_akreditasi')
            ->select('*')
            ->where('gambar_akreditasi.id_akreditasi',$id_akreditasi)
            ->orderBy('id_akreditasi','DESC')
            ->get();
        return $query;
    }
}
