<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\Paginator;
use App\Models\Site_model;
use App\Models\Proyek_model;
Paginator::useBootstrap();

class Aksi extends Controller
{
    // Main page
    public function index()
    {
        $myproyek       = new Proyek_model();
        $proyek         = $myproyek->semua();
		$status_site 	= DB::table('status_site')->orderBy('urutan','ASC')->get();
        $status_proyek  = DB::table('status_proyek')->orderBy('urutan','ASC')->get();

		$data = array(  'title'			=> 'Aksi Penatalayanan Air',
						'deskripsi' 	=> 'Aksi Penatalayanan Air',
                        'keywords'  	=> 'Aksi Penatalayanan Air',
                        'proyek'        => $proyek,
                        'proyeks'       => $proyek,
						'status_site'	=> $status_site,
                        'status_proyek' => $status_proyek,
                        'content'		=> 'aksi/index'
                    );
        return view('layout/wrapper',$data);
    }

    // Main page
    public function status($slug_status_site)
    {
        $site_config   = DB::table('konfigurasi')->first();
        $status_site    = DB::table('status_site')->where('slug_status_site',$slug_status_site)->orderBy('urutan','ASC')->first();
        $mysite       = new Site_model();
        $site         = $mysite->status_site($status_site->id_status_site);

        $data = array(  'title'         => $status_site->nama_status_site,
                        'deskripsi'     => $status_site->nama_status_site,
                        'keywords'      => $status_site->nama_status_site,
                        'site'          => $site,
                        'sites'          => $site,
                        'status_site'   => $status_site,
                        'content'       => 'aksi/status_site'
                    );
        return view('layout/wrapper',$data);
    }
}
