<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class Kategori_akreditasi extends Controller
{
    // Index
    public function index()
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
		$kategori_akreditasi 	= DB::table('kategori_akreditasi')->orderBy('urutan','ASC')->get();

		$data = array(  'title'                 => 'Kategori Provider Akreditasi',
						'kategori_akreditasi'	=> $kategori_akreditasi,
                        'content'               => 'admin/kategori_akreditasi/index'
                    );
        return view('admin/layout/wrapper',$data);
    }

    // tambah
    public function tambah(Request $request)
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	request()->validate([
					        'nama_kategori_akreditasi' => 'required|unique:kategori_akreditasi',
					        'urutan' 		       => 'required',
					        ]);
    	$slug_kategori_akreditasi = Str::slug($request->nama_kategori_akreditasi, '-');
        DB::table('kategori_akreditasi')->insert([
            'nama_kategori_akreditasi'  => $request->nama_kategori_akreditasi,
            'slug_kategori_akreditasi'	=> $slug_kategori_akreditasi,
            'urutan'   		        => $request->urutan
        ]);
        return redirect('admin/kategori_akreditasi')->with(['sukses' => 'Data telah ditambah']);
    }

    // edit
    public function edit(Request $request)
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	request()->validate([
					        'nama_kategori_akreditasi' => 'required',
					        'urutan'               => 'required',
					        ]);
    	$slug_kategori_akreditasi = Str::slug($request->nama_kategori_akreditasi, '-');
        DB::table('kategori_akreditasi')->where('id_kategori_akreditasi',$request->id_kategori_akreditasi)->update([
            'nama_kategori_akreditasi'  => $request->nama_kategori_akreditasi,
            'slug_kategori_akreditasi'	=> $slug_kategori_akreditasi,
            'urutan'                => $request->urutan
        ]);
        return redirect('admin/kategori_akreditasi')->with(['sukses' => 'Data telah diupdate']);
    }

    // Delete
    public function delete($id_kategori_akreditasi)
    {
    	if(Session()->get('username')=="") { return redirect('login')->with(['warning' => 'Mohon maaf, Anda belum login']);}
    	DB::table('kategori_akreditasi')->where('id_kategori_akreditasi',$id_kategori_akreditasi)->delete();
    	return redirect('admin/kategori_akreditasi')->with(['sukses' => 'Data telah dihapus']);
    }
}
